package com.redc4ke.taniechlanie.data

data class Shop(
        val id: Int,
        val name: String)

