package com.redc4ke.taniechlanie.data

import java.io.File

data class Category(
        val id: Int,
        val name: String,
        val image: File?
)